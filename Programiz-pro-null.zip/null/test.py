from PAL import mRNA_Compile, wrap_mrna_for_eukaryotes

pal_code = """
FUNC DNA_BINDING_DOMAIN
    BIND DNA
    SIGNAL NUCLEUS
END FUNC

FUNC PHOSPHORYLATION_DOMAIN
    CATALYZE PHOSPHORYLATION
    SIGNAL CYTOPLASM
END FUNC

FUNC JUMP_MOTOR
    MOTOR JUMP
    LINK
END FUNC

START
CALL DNA_BINDING_DOMAIN
CALL PHOSPHORYLATION_DOMAIN
CALL JUMP_MOTOR
ATC GFP
END
"""

mrna = mRNA_Compile(pal_code)
injectable = wrap_mrna_for_eukaryotes(mrna)
print("Universal CRISPR Protein v1", injectable)
